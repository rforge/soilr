#
# vim:set ff=unix expandtab ts=2 sw=2:
require(RUnit)
test.GeneralNlModel=function(){
  attr(GeneralNlModel,"ex")()
}
