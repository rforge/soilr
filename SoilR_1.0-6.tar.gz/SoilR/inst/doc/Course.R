### R code from vignette source 'Course.Rnw'

###################################################
### code chunk number 1: Course.Rnw:73-74
###################################################
require("SoilR")


###################################################
### code chunk number 2: Course.Rnw:81-83
###################################################
data(CourseExample_R14)
data(C14Atm_NH)


###################################################
### code chunk number 3: Course.Rnw:88-109
###################################################
     #define a small helper function
     bars=function(x,y,err,...){
        points(x,y,...)
        arrows(x,y-err,x,y+err,code=3,angle=90,...)
     }
     data(CourseExample_R14)
     c1="black"
     c2="red"
     x=DataC$time
     xl=min(x);xu=max(x);os=0.05*(xu-xl); xlimits=c(xl-os,xu+os)
     y1=DataC$C1
     y2=DataC$C2
     err=DataC$sd
     ylimits=range(y1+err,y2+err,y1-err,y2-err)
     #draw empty field
     plot(NA, xlim=xlimits, ylim=ylimits)
     w=3
     #draw the error arrow
     bars(x,y1,err,col=c1,lwd=w)
     bars(x,y2,err,col=c2,lwd=w)
     


###################################################
### code chunk number 4: Course.Rnw:115-125
###################################################
     x=DataR14$time
     xl=min(x);xu=max(x);os=0.05*(xu-xl); xlimits=c(xl-os,xu+os)
     y=DataR14$R14t
     err=DataR14$sd
     ylimits=range(y-err,y+err)
     #draw empty field
     plot(NA , xlim=xlimits , ylim=ylimits)
     w=3
     #draw the error arrow
     bars(x,y,err,col=c1,lwd=w)


###################################################
### code chunk number 5: Course.Rnw:131-141
###################################################
     x=DataI$time
     xl=min(x);xu=max(x);os=0.05*(xu-xl); xlimits=c(xl-os,xu+os)
     y=DataI$In
     err=DataI$sd
     ylimits=range(y-err,y+err)
     #draw empty field
     plot(NA , xlim=xlimits , ylim=ylimits)
     w=3
     #draw the error arrow
     bars(x,y,err,col=c1,lwd=w)


###################################################
### code chunk number 6: Course.Rnw:147-150
###################################################
     x=C14Atm_NH$YEAR
     y=C14Atm_NH$Atmosphere
     plot(x,y,lwd=w)


###################################################
### code chunk number 7: Course.Rnw:160-161
###################################################
#?Models


###################################################
### code chunk number 8: Course.Rnw:198-200
###################################################
library("SoilR")
library("FME")


###################################################
### code chunk number 9: setTime
###################################################
t_start=1978
t_end=2008
#t_start=t_end-30
indices=(C14Atm_NH$YEAR>=t_start & C14Atm_NH$YEAR < t_end)
time=C14Atm_NH$YEAR[indices]


###################################################
### code chunk number 10: Course.Rnw:211-212
###################################################
C0=as.numeric(DataC[1,c("C1","C2")])


###################################################
### code chunk number 11: Course.Rnw:218-219
###################################################
gam=0.6


###################################################
### code chunk number 12: Course.Rnw:223-224
###################################################
xi=1


###################################################
### code chunk number 13: Course.Rnw:231-234
###################################################
th=5730
#note that lambda is negative and has the unit y^-1
lambda=log(0.5)/th 


###################################################
### code chunk number 14: Course.Rnw:252-270
###################################################
pf<-function(ks,pass=FALSE){
    mod=TwopParallelModel14(
            time,
            ks,
            C0,
            F0=c(0,0),
            In=DataI,
            gam=gam,
            xi=xi,
            FcAtm=C14Atm_NH,
            lambda=lambda,
            pass=pass
    ) 
    Cs=getC(mod)
    print("pf")
    R14t=getF14R(mod)
    return(data.frame(time=time,R14t=R14t,C1=Cs[,1],C2=Cs[,2]))
}


###################################################
### code chunk number 15: c
###################################################
t_start=1978
t_end=2008
#t_start=t_end-30
indices=(C14Atm_NH$YEAR>=t_start & C14Atm_NH$YEAR < t_end)
time=C14Atm_NH$YEAR[indices]
 C0=c(0.5,0.5)
 F0=c(0,0)
 
 l=length(time)
 iC=c(seq(1,l,4),l)
 In=rep(0.05,length(iC))
 stdIn=0.05*max(In)
 errIn=rnorm(sd=stdIn,n=length(In))
 DataI <- data.frame(
     time=time[iC],
     In  =  In+errIn
     ,
     sd=stdIn
 )
 pars=c(k1=-0.3,k2=-0.5)
 Df<-pf(pars)
 #Now we first select a view points, disturb the data and plot it \figref{fig:distdata}. 
 iR14=c(seq(1,l,8),l)
 #iR14=c(1,l)
 stdC=0.2*max(Df$C1)
 std14=0.2*max(Df$R14t)
 errR14=rnorm(sd=std14,n=length(iR14))
 errC1=rnorm(sd=stdC,n=length(iC))
 errC2=rnorm(sd=stdC,n=length(iC))
DataR14 <- data.frame(
    time=time[iR14],
    R14t=Df$R14t[iR14]+errR14,
    sd=std14
    )
DataC <- data.frame(
    time=time[iC],
    C1  =  Df$C1[iC]+errC1,
    C2  =  Df$C2[iC]+errC2,
    sd=stdC
)
# #the next line has to be commented out for the real vignette
#datadir="/home/mm/SoilR/RPackages/SoilR/pkg/data/"
# save(DataR14,DataC,DataI,file=paste(datadir,"CourseExample_R14",".rda",sep=""),ascii=TRUE)
# save(DataR14,file=paste(datadir,"DataR14",".rda",sep=""),ascii=TRUE)
# save(DataC,file=paste(datadir,"DataC",".rda",sep=""),ascii=TRUE)
# save(DataI,file=paste(datadir,"DataI",".rda",sep=""),ascii=TRUE)


###################################################
### code chunk number 16: Course.Rnw:324-348
###################################################
pars=c(k1=-0.1,k2=-0.2)
Df=pf(pars)
c1="black"; c2="red";lty1=1;lty2=2
plot(1:20,1:20)
print(DataC[,"time"])
plot(DataC[,"time"],
     DataC[,"C1"],
     col=c1,lty=lty1,
     xlab="time",
     ylab="C content of the pools"
)
points(
       DataC[,"time"],
       DataC[,"C2"],
       col=c2,
       lty=lty1
)
lines(Df$time,Df$C1,col=c1,lty=lty1)
lines(Df$time,Df$C2,col=c2,lty=lty1)
legend("topright",
       legend=c("C content of pool 1","C content of pool 2"),
       col=c(c1,c2)
      # ,lty=c(lty1,lty2)
       ,bty="n")


###################################################
### code chunk number 17: Course.Rnw:353-356
###################################################
plot(DataR14[,"time"],DataR14[,"R14t"],lty=1,col=c1,
     xlab="Years",ylab=expression(paste(Delta^14,"C "," in respiration (permil)")))
lines(Df$time,Df$R14t,col=c1,lty=lty1)


###################################################
### code chunk number 18: Course.Rnw:383-401
###################################################
    DfCost <- function(pars){
        Df <- pf(pars,pass=TRUE)
        Ccost=modCost(
                    model=Df,
                    obs=DataC,
                    err="sd"
                    #,scaleVar=TRUE
                    )
        return(
               modCost(
                       model=Df,
                       obs=DataR14,
                       err="sd",
                       #,scaleVar=TRUE
                       cost=Ccost)
               )
    }
    plot(DfCost(pars),xlab="time")


###################################################
### code chunk number 19: Course.Rnw:412-415
###################################################
Sfun <- sensFun(DfCost,pars)
summary(Sfun)
plot(Sfun,which=c("R14t","C1","C2"),xlab="time",lwd=2)


###################################################
### code chunk number 20: Course.Rnw:422-423
###################################################
pairs(Sfun,which=c("R14t","C1","C2"),col=c("green","blue","red"))


###################################################
### code chunk number 21: Course.Rnw:430-431
###################################################
ident <- collin(Sfun,parset=c("k1","k2"))


###################################################
### code chunk number 22: Course.Rnw:441-445
###################################################
    Fit <- modFit(f=DfCost,upper=c(0.2,0),p=c(0.1,-0.1))
    print(Fit$par) 
    plot(Fit)
    summary(Fit)


###################################################
### code chunk number 23: Course.Rnw:454-482
###################################################
Dfinal=pf(Fit$par)
allval=rbind(Df[,c("C1","C2")],Dfinal[,c("C1","C2")],DataC[,c("C1","C2")])
    plot(Df$time,Df$C1, type="l", lty=lty2,
         ylim=c( min(allval) ,max(allval)),
         col=c1)
    lines(Df$time,Df$C2,lty=lty2,col=c2)
    lines(Dfinal$time,Dfinal$C1,lty=lty1,col=c1)
    lines(Dfinal$time,Dfinal$C2,lty=lty1,col=c2)
    points(
           DataC[,"time"],
           DataC[,"C1"],
           col=c1,
           lty=lty1
    )
    points(
           DataC[,"time"],
           DataC[,"C2"],
           col=c2,
           lty=lty1
    )
legend("topright",
       legend=c(
                 "pool 1 initial"
                ,"pool 2 initial"
                ,"pool 1 final"
                ,"pool 2 final"
                ),
       col=c(c1,c2,c1,c2),lty=c(lty2,lty2,lty1,lty1),bty="n")


###################################################
### code chunk number 24: Course.Rnw:487-489
###################################################
    plot(Df$time,Df$R14t,type="l",lty=lty1,col=c1)
    lines(Dfinal$time,Dfinal$R14t,lty=lty2,col=c2)


###################################################
### code chunk number 25: Course.Rnw:496-507
###################################################
    #var0 <- Fit$var_ms_unweighted
    #cov0 <- summary(Fit)$cov.scaled#*2.4^2/5
    #p=Fit$par
    niter=200
    t1=Sys.time()
    MCMC  <- modMCMC(f=DfCost,niter=niter,p=Fit$par)
    t2=Sys.time()

    print(t1-t2)
    summary(MCMC)
    plot(MCMC, Full = TRUE)


###################################################
### code chunk number 26: Course.Rnw:512-516
###################################################
    sR=sensRange(func=pf, parInput=MCMC$par)
    plot(summary(sR)
         ,xlab="Years"
     )


###################################################
### code chunk number 27: Course.Rnw:523-524
###################################################
    pairs(MCMC, nsample = niter/4)


