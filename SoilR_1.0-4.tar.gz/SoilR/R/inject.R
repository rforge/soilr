inject=function(fun,...){fun(...)}
