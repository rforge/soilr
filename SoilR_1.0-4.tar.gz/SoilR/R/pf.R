   #pf=function(str){print(paste(str,"=",eval(parse(text=str))))}
