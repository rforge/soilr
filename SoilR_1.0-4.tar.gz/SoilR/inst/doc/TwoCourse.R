### R code from vignette source 'TwoCourse.Rnw'

###################################################
### code chunk number 1: TwoCourse.Rnw:73-74
###################################################
require("SoilR")


###################################################
### code chunk number 2: TwoCourse.Rnw:81-83
###################################################
data(CourseExample_R14)
data(C14Atm_NH)


###################################################
### code chunk number 3: TwoCourse.Rnw:88-109
###################################################
     #define a small helper function
     bars=function(x,y,err,...){
        points(x,y,...)
        arrows(x,y-err,x,y+err,code=3,angle=90,...)
     }
     data(CourseExample_R14)
     c1="black"
     c2="red"
     x=DataC$time
     xl=min(x);xu=max(x);os=0.05*(xu-xl); xlimits=c(xl-os,xu+os)
     y1=DataC$C1
     y2=DataC$C2
     err=DataC$sd
     ylimits=range(y1+err,y2+err,y1-err,y2-err)
     #draw empty field
     plot(NA, xlim=xlimits, ylim=ylimits)
     w=3
     #draw the error arrow
     bars(x,y1,err,col=c1,lwd=w)
     bars(x,y2,err,col=c2,lwd=w)
     


