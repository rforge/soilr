require(RUnit)
test.GeneralNlModel=function(){
  attr(GeneralNlModel,"ex")()
}
