require(RUnit)
test.GeneralModel_14=function(){
  attr(GeneralModel_14,"ex")()
}
