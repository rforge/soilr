# This test function is automatically produced by the python script:/home/mm/SoilR/RPackages/SoilR/pkg/inst/tests/Rexample.py
test.op=function(){
    library(SoilR)
    str <- ?SoilR


 }
